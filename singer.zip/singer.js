

window.document.querySelector('#header').innerText = 'Das batalhas à sujeira das ruas, Murica.'






window.document.querySelector('#cardmurica').src = 'muricax.jpg'
window.document.querySelector('#footer').innerText = "@Dois Mil e Sempre"
window.document.querySelector('#t1').innerText = 'Nome: Murilo Fellipe;'
window.document.querySelector('#t2').innerText = 'Vulgo: Murica'
window.document.querySelector('#t3').innerText = 'Primeiro Album: "Fome" - 2019'
window.document.querySelector('#t4').innerText = 'Gênero: Hip-hop (Rap Boombap)'
window.document.querySelector('#t5').innerText = ''

var anchor1 = window.document.querySelector('#t6')
anchor1.innerText = 'Instagram'
anchor1.href = "'https://www.instagram.com/murica_sujao/?hl=pt-br'"

var anchor2 = window.document.querySelector('#t7')
anchor2.innerText = 'Canal do Youtube'
anchor2.href = "'https://www.youtube.com/channel/UCu0LXW83dH-V82ZhliYCTIw'"



